﻿using Dapper;
using DBHandler.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBHandler
{
    public class DBOperation
    {
        private readonly DapperORM _dapperOrm = new DapperORM();

        public IEnumerable<SENSOR> GetSensorList(out SP_RESULT spResult)
        {
            var param = new DynamicParameters();
            param.AddDynamicParams(new
            {
            });
            return _dapperOrm.ReturnList<SENSOR>("SP_GET_SENSOR_LIST", param, out spResult).ToList();

        }


    }
}
